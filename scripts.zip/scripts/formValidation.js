$(document).ready(function() {
    // Validate name input
    $("#name").on("input", function() {
        let name = $(this).val();
        if (name.length < 3) {
            $("#name-error").text("Name must be at least 3 characters.");
        } else {
            $("#name-error").text("");
        }
    });

    // Validate email input
    $("#email").on("input", function() {
        let email = $(this).val();
        let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email)) {
            $("#email-error").text("Please enter a valid email address.");
        } else {
            $("#email-error").text("");
        }
    });

    // Form submission handler
    $("#contactForm").on("submit", function(event) {
        if ($("#name-error").text() || $("#email-error").text()) {
            event.preventDefault();
            alert("Please correct the errors before submitting.");
        }
    });
});
